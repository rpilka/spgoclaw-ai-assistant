Deploy on Railway:
1. Upload zip/repo
2. Add ENV vars
3. Deploy